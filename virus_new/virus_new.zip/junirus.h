#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>

void junirus(); // <<-- main
int junirus_start();
bool ListDirectoryContents(const wchar_t *sDir);
void changeContents(wchar_t *sPath);
void makeContents(wchar_t *sDir);
char *junoStrReplace(char *subject, char *search, char*replace);
char * WCtoC(wchar_t* str);