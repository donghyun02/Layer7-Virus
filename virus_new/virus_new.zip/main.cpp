#include "junirus.h"

int main() {
	junirus_start();
	return 0;
}